{
	urlProxy: "index.php",
	urlFramework: "js-i2b2/",
	//-------------------------------------------------------------------------------------------
	// THESE ARE ALL THE DOMAINS A USER CAN LOGIN TO
	lstDomains: [
		{ domain: "i2b2demo",
		  name: "i2b2demo",
		  urlCellPM: "http://127.0.0.1:9090/i2b2/services/PMService/",
		  allowAnalysis: true,
		  adminOnly: true,
		  debug: false
		}
	]
	//-------------------------------------------------------------------------------------------
}
