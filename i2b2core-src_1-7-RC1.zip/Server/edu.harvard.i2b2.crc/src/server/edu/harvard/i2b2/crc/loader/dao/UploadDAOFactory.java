package edu.harvard.i2b2.crc.loader.dao;

import javax.sql.DataSource;

import edu.harvard.i2b2.crc.loader.datavo.loader.DataSourceLookup;

public class UploadDAOFactory implements IUploaderDAOFactory {

	public ConceptDAO getConceptDAO() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public ModifierDAO getModifierDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	public ObservationFactDAO getObservationDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	public PatientDAO getPatientDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	public PidDAO getPidDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	public ProviderDAO getProviderDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	public UploadStatusDAO getUploadStatusDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	public VisitDAO getVisitDAO() {
		// TODO Auto-generated method stub
		return null;
	}

	public DataSourceLookup getDataSourceLookup() {
		// TODO Auto-generated method stub
		return null;
	}

	public DataSource getDataSource() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setDataSource(DataSource dataSource) {
		// TODO Auto-generated method stub

	}

	public IEidDAO getEidDAO() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public IMissingTermDAO getMissingTermDAO() {
		// TODO Auto-generated method stub
		return null;
	}

}
