package edu.harvard.i2b2.crc.dao.pdo;

public class DimensionTable {

	public static final String PATIENT_DIMENSION =  "PATIENT_DIMENSION";
	public static final String VISIT_DIMENSION =  "VISIT_DIMENSION";
	
}
