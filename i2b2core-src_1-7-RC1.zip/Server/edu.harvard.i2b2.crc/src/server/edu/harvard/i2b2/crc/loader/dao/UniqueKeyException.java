package edu.harvard.i2b2.crc.loader.dao;

import edu.harvard.i2b2.common.exception.I2B2Exception;

public class UniqueKeyException extends I2B2Exception {
	
	public UniqueKeyException() { 
		
	}
	
	public UniqueKeyException(String message) { 
		
	}
	

}
