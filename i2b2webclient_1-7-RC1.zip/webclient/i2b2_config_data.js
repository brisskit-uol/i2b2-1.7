{
	urlProxy: "index.php",
	urlFramework: "js-i2b2/",
	//-------------------------------------------------------------------------------------------
	// THESE ARE ALL THE DOMAINS A USER CAN LOGIN TO
	lstDomains: [
		{ domain: "HarvardDemo",
		  name: "HarvardDemo",
		  urlCellPM: "http://webservices.i2b2.org/i2b2/rest/PMService/",
		  allowAnalysis: true,
		  debug: false
		}
	]
	//-------------------------------------------------------------------------------------------
}
